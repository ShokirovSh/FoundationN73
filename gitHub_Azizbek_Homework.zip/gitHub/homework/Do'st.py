import os
os.system("clear")

n = int(input())
if n % 4 == 3 or n % 4 == 0:
	print("B")
else :
  	print("A")
	  
